package com.accenture.academico.service;

import java.util.List;

import com.accenture.academico.model.TituloTitulacao;

public interface TituloTitulacaoService {
	public void addTitulo(TituloTitulacao t);

	public List<TituloTitulacao> listTitulos();

	public void updateTitulo(TituloTitulacao t);

	public void deleteTitulo(TituloTitulacao t);


}
