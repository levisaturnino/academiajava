package com.accenture.academico.service;

import java.util.List;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;

import org.springframework.stereotype.Service;
//import org.springframework.transaction.annotation.Transactional;

import com.accenture.academico.model.Pessoa;
import com.accenture.academico.dao.PessoaDAO;



@ManagedBean(name = "PessoaService")
@SessionScoped
@Service

public class PessoaServiceImpl implements PessoaService {

	private PessoaDAO PessoaDAO;

	public void setPessoaDAO(PessoaDAO PessoaDAO) {
		this.PessoaDAO = PessoaDAO;
	}

	@Override
	//@Transactional
	public void addPessoa(Pessoa p) {
		// TODO Auto-generated method stub
		PessoaDAO.addPessoa(p);		

	}

	@Override
	public List<Pessoa> listPessoas() {
		// TODO Auto-generated method stub
		return PessoaDAO.listPessoas();
	}

	@Override
	//@Transactional
	public void updatePessoa(Pessoa p) {
		// TODO Auto-generated method stub

	}

	@Override
	public void deletePessoa(Pessoa p) {
		// TODO Auto-generated method stub

	}

}
