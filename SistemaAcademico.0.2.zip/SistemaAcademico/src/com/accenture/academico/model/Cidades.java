package com.accenture.academico.model;

public enum Cidades {
	
	RECIFE, JABOAT�O, OLINDA, CARUARU, PETROLINA, PAULISTA, CABO, CAMARAGIBE, GARANHUNS, VIT�RIA;

}
