package com.accenture.academico.model;

public class Publicacao {

	private int idPublicacao;
	private String tituloPublicacao;
	private String descricaoPublicacao;
	private int idAluno;
	private int idProfessor;

	public int getIdPublicacao() {
		return idPublicacao;
	}

	public void setIdPublicacao(int idPublicacao) {
		this.idPublicacao = idPublicacao;
	}

	public String getTituloPublicacao() {
		return tituloPublicacao;
	}

	public void setTituloPublicacao(String tituloPublicacao) {
		this.tituloPublicacao = tituloPublicacao;
	}

	public String getDescricaoPublicacao() {
		return descricaoPublicacao;
	}

	public void setDescricaoPublicacao(String descricaoPublicacao) {
		this.descricaoPublicacao = descricaoPublicacao;
	}

	public int getIdAluno() {
		return idAluno;
	}

	public void setIdAluno(int idAluno) {
		this.idAluno = idAluno;
	}

	public int getIdProfessor() {
		return idProfessor;
	}

	public void setIdProfessor(int idProfessor) {
		this.idProfessor = idProfessor;
	}

}
