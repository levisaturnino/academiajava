package com.accenture.academico.model;

public enum TipoPessoa {
	
	ALUNO, PROFESSOR;

}
