package com.accenture.academico.model;

public class MeioComunicacao {

	private int idComunicacao;
	private int DescricaoComunicacao;

	public int getIdComunicacao() {
		return idComunicacao;
	}

	public void setIdComunicacao(int idComunicacao) {
		this.idComunicacao = idComunicacao;
	}

	public int getDescricaoComunicacao() {
		return DescricaoComunicacao;
	}

	public void setDescricaoComunicacao(int descricaoComunicacao) {
		DescricaoComunicacao = descricaoComunicacao;
	}

}
