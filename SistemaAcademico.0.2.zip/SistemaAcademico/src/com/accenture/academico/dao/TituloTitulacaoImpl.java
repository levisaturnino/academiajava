package com.accenture.academico.dao;

import java.util.List;

import com.accenture.academico.model.TituloTitulacao;

public class TituloTitulacaoImpl implements TituloTitulacaoDAO {

	@Override
	public void addTitulo(TituloTitulacao t) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public List<TituloTitulacao> listTitulos() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void updateTitulo(TituloTitulacao t) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void deleteTitulo(TituloTitulacao t) {
		// TODO Auto-generated method stub
		
	}

}
