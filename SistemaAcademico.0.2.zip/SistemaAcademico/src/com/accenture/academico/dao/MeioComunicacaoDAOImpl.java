package com.accenture.academico.dao;

import java.util.List;
import com.accenture.academico.model.MeioComunicacao;

public class MeioComunicacaoDAOImpl implements MeioComunicacaoDAO {

	@Override
	public void addMeioComunicacao(MeioComunicacao m) {
		// TODO Auto-generated method stub

	}

	@Override
	public List<MeioComunicacao> listMeiosComunicacao() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void updateMeioComunicacao(MeioComunicacao m) {
		// TODO Auto-generated method stub

	}

	@Override
	public void deleteMeioComunicacao(MeioComunicacao m) {
		// TODO Auto-generated method stub

	}

}
