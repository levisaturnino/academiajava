package com.accenture.academico.dao;

import java.util.List;
import com.accenture.academico.model.Aluno;

public class AlunoDAOImpl implements AlunoDAO {

	@Override
	public void addAluno(Aluno p) {
		// TODO Auto-generated method stub

	}

	@Override
	public List<Aluno> listAlunos() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void updateAluno(Aluno p) {
		// TODO Auto-generated method stub

	}

	@Override
	public void deleteAluno(Aluno p) {
		// TODO Auto-generated method stub

	}

}
