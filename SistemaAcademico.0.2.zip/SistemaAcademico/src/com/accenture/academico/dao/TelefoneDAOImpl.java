package com.accenture.academico.dao;

import java.util.List;

import com.accenture.academico.model.Telefone;

public class TelefoneDAOImpl implements TelefoneDAO{

	@Override
	public void addTelefone(Telefone t) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public List<Telefone> listTelefones() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void updateTelefone(Telefone t) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void deleteTelefone(Telefone t) {
		// TODO Auto-generated method stub
		
	}

}
