package com.accenture.academico.model;

public class Endereco {

	private int idEndereco;
	private String logradouro;
	private String bairro;
	private int numero;
	private Enum cidade;
	private String uf;
	
	private enum Cidades {
	       RECIFE, JABOAT�O, OLINDA, CARUARU, PETROLINA, PAULISTA, CABO, CAMARAGIBE, GARANHUNS, VIT�RIA;
	}
	

	public int getIdEndereco() {
		return idEndereco;
	}

	public void setIdEndereco(int idEndereco) {
		this.idEndereco = idEndereco;
	}

	public String getLogradouro() {
		return logradouro;
	}

	public void setLogradouro(String logradouro) {
		this.logradouro = logradouro;
	}

	public String getBairro() {
		return bairro;
	}

	public void setBairro(String bairro) {
		this.bairro = bairro;
	}

	public int getNumero() {
		return numero;
	}

	public void setNumero(int numero) {
		this.numero = numero;
	}

	public Enum getCidade() {
		return cidade;
	}

	public void setCidade(Enum cidade) {
		this.cidade = cidade;
	}

	public String getUf() {
		return uf;
	}

	public void setUf(String uf) {
		this.uf = uf;
	}

}
