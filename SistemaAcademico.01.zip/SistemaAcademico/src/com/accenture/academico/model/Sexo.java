package com.accenture.academico.model;

public enum Sexo {
	
	MASCULINO, FEMININO, OUTROS;

}
