package com.accenture.academico.model;

public class Pessoa {

	private int idPessoa;
	private String nome;
	private String cpf;
	private Enum sexo;
	private Enum tipoPessoa;
	
	public enum Sexo {
	       MASCULINO, FEMININO, OUTROS;
	}
	public enum TipoPessoa {
	       ALUNO, PROFESSOR;
	}
	

	public int getIdPessoa() {
		return idPessoa;
	}

	public void setIdPessoa(int idPessoa) {
		this.idPessoa = idPessoa;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public String getCpf() {
		return cpf;
	}

	public void setCpf(String cpf) {
		this.cpf = cpf;
	}

	public Enum getSexo() {
		return sexo;
	}

	public void setSexo(Enum sexo) {
		this.sexo = sexo;
	}

	public Enum getTipoPessoa() {
		return tipoPessoa;
	}

	public void setTipoPessoa(Enum tipoPessoa) {
		this.tipoPessoa = tipoPessoa;
	}

}
