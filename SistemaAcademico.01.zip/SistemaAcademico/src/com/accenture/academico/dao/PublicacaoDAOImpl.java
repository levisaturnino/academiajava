package com.accenture.academico.dao;

import java.util.List;
import com.accenture.academico.model.Publicacao;

public class PublicacaoDAOImpl implements PublicacaoDAO{

	@Override
	public void addPublicacao(Publicacao p) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public List<Publicacao> listPublicacoes() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void updatePublicacao(Publicacao p) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void deletePublicacao(Publicacao p) {
		// TODO Auto-generated method stub
		
	}
	
	

}
