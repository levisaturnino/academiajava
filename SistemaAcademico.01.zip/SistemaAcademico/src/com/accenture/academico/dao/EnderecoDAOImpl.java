package com.accenture.academico.dao;

import java.util.List;

import com.accenture.academico.model.Endereco;

public class EnderecoDAOImpl implements EnderecoDAO {

	@Override
	public void addEndereco(Endereco e) {
		// TODO Auto-generated method stub

	}

	@Override
	public List<Endereco> listEnderecos() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void updateEndereco(Endereco e) {
		// TODO Auto-generated method stub

	}

	@Override
	public void deleteEndereco(Endereco e) {
		// TODO Auto-generated method stub

	}

}
