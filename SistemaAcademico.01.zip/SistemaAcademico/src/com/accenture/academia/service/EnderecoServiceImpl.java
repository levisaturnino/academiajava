package com.accenture.academia.service;

import java.util.List;

import com.accenture.academico.model.Endereco;

public class EnderecoServiceImpl implements EnderecoService{

	@Override
	public void addEndereco(Endereco e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public List<Endereco> listEnderecos() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void updateEndereco(Endereco e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void deleteEndereco(Endereco e) {
		// TODO Auto-generated method stub
		
	}
	
	

}
