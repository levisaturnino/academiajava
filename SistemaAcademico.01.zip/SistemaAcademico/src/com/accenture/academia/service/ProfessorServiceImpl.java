package com.accenture.academia.service;

import java.util.List;

import com.accenture.academico.model.Professor;

public class ProfessorServiceImpl implements ProfessorService{

	@Override
	public void addProfessor(Professor p) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public List<Professor> listProfessores() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void updateProfessor(Professor p) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void deleteProfessor(Professor p) {
		// TODO Auto-generated method stub
		
	}
	
	

}
