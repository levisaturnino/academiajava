package com.accenture.academia.service;

import java.util.List;

import com.accenture.academico.model.Titulo;

public interface TituloService {
	public void addTitulo(Titulo t);

	public List<Titulo> listTitulos();

	public void updateTitulo(Titulo t);

	public void deleteTitulo(Titulo t);


}
