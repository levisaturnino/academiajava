package com.accenture.academia.service;

import java.util.List;

import com.accenture.academico.model.Aluno;

public class AlunoServiceImpl implements AlunoService {

	@Override
	public void addAluno(Aluno a) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public List<Aluno> listAlunos() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void updateAluno(Aluno a) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void deleteAluno(Aluno a) {
		// TODO Auto-generated method stub
		
	}}
