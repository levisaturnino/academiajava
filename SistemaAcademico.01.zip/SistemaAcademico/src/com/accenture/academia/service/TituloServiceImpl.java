package com.accenture.academia.service;

import java.util.List;

import com.accenture.academico.model.Titulo;

public class TituloServiceImpl implements TituloService{

	@Override
	public void addTitulo(Titulo t) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public List<Titulo> listTitulos() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void updateTitulo(Titulo t) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void deleteTitulo(Titulo t) {
		// TODO Auto-generated method stub
		
	}

}
