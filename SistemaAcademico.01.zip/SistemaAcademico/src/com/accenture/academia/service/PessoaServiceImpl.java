package com.accenture.academia.service;

import java.util.List;

import com.accenture.academico.model.Pessoa;

public class PessoaServiceImpl implements PessoaService{

	@Override
	public void addPessoa(Pessoa p) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public List<Pessoa> listPessoas() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void updatePessoa(Pessoa p) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void deletePessoa(Pessoa p) {
		// TODO Auto-generated method stub
		
	}
	
	
	
	

}
